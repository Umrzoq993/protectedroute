// Card.jsx

import React from "react";
import styled from "styled-components";
import nature from "./nature.jpg";

const Card = () => {
  return (
    <CardWrapper>
      <div className="image-container">
        <img src={nature} alt="lemon" />
      </div>

      <div className="content">
        <div className="heading">
          <h2 className="heading__title">
            Content <span className="next-line">cards title</span>
          </h2>
          <h3 className="heading__subtitle">Card subtitle</h3>
        </div>

        <div className="details">
          <p className="details__text">
            Lorem ipsum dolor sit amet, consect etur adipi scing elit
            <span className="next-line">sed do eiusmod tempor</span>
          </p>
          <button className="details__btn">Tertiary Button</button>
        </div>
      </div>
    </CardWrapper>
  );
};

const CardWrapper = styled.div`
  border-radius: 8px;
  background: #f5f5f6;
  width: 180px; /* Adjust the width to your preference */

  .image-container {
    height: 100px; /* Adjust the height to your preference */
    border-radius: 8px 8px 0 0;
    overflow: hidden;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }

  .content {
    padding: 12px; /* Adjust the padding to your preference */

    .heading {
      .heading__title {
        font-weight: 400;
        font-size: 16px; /* Adjust the font size to your preference */
        padding-bottom: 6px; /* Adjust the padding to your preference */
        line-height: 20px;
      }

      .heading__subtitle {
        font-weight: 600;
        font-size: 14px; /* Adjust the font size to your preference */
        color: #4b4c53;
        padding-bottom: 10px; /* Adjust the padding to your preference */
      }
    }

    .details {
      .details__text {
        font-weight: 200;
        line-height: 18px; /* Adjust the line height to your preference */
        color: #4b4c53;
        font-size: 12px; /* Adjust the font size to your preference */
        padding-bottom: 14px; /* Adjust the padding to your preference */
        word-spacing: 1px;
      }

      .details__btn {
        border: none;
        background: none;
        font-size: 14px; /* Adjust the font size to your preference */
        font-weight: 700;
        letter-spacing: 1px;
        word-spacing: -4px;
        color: #6267a1;
      }
    }

    .next-line {
      display: inline-block;
    }
  }
`;

export default Card;
