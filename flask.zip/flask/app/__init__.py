from flask import Flask
from flask_jwt_extended import JWTManager


app = Flask(__name__)
app.config.from_pyfile('../config.py')

from app.routes.routes import list_items
from app.routes.user_routes import login, register

# Setup the Flask-JWT-Extended extension
app.config['JWT_SECRET_KEY'] = 'your_jwt_secret_key'  # Change this to a random secret key
jwt = JWTManager(app)
