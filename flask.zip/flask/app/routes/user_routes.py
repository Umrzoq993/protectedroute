from app import app
from flask import request, jsonify
from app.models.user_models import create_user, verify_user
from flask_jwt_extended import create_access_token

@app.route('/register', methods=['POST'])
def register():
    print('Requesting registration')
    data = request.json
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')
    
    if not username or not password:
        return jsonify({'error': 'Invalid username or password'}), 400
    
    if create_user(username, password, role):
        # User was successfully created
        return jsonify({"message": "User registration successful"}), 201
    else:
        # User already exists
        return jsonify({"error": "User already registered"}), 409
    
    
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Please provide username and password'}), 400
    
    user = verify_user(username, password)
    if user:
        # Create JWT token
        access_token = create_access_token(identity=username)
        return jsonify(access_token=access_token), 200
    else:
        return jsonify({"error": "Invalid username or password"}), 401
