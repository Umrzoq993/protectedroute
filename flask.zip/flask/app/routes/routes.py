from app import app
from flask import jsonify, request
from app.models.models import get_all_items # Import other CRUD operation functions

@app.route('/cars', methods=['GET'])
def list_items():
    items = get_all_items()
    return jsonify(items)

# Define routes for CREATE, UPDATE, DELETE operations
