from werkzeug.security import generate_password_hash, check_password_hash
from app import app
from flask_mysqldb import MySQL

mysql = MySQL(app)

def create_user(username, password, role):
    # Create a cursor
    cur = mysql.connection.cursor()
    
    # Check if user already exists
    cur.execute("SELECT * FROM users WHERE username = %s", [username])
    if cur.fetchone():
        # User already exists
        cur.close()
        return False  # Indicate that the user was not created because they already exist
    
    # User does not exist, proceed with creating a new user
    hashed_password = generate_password_hash(password + username)
    cur.execute("INSERT INTO users(username, password, role) VALUES (%s, %s, %s)", (username, hashed_password, role))
    mysql.connection.commit()
    cur.close()
    return True  # Indicate that the user was successfully created

# Assuming this function is in the same file where `create_user` exists
def verify_user(username, password):
    cur = mysql.connection.cursor()
    # Fetch user by username
    cur.execute("SELECT password, role FROM users WHERE username = %s", [username])
    user = cur.fetchone()
    cur.close()
    
    # If user exists and password matches
    if user and check_password_hash(user[0], password + username):
        return {"username": username, "role": user[1]}  # Return some user details
    else:
        return None  # Invalid credentials