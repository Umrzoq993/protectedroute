from app import app
from flask_mysqldb import MySQL

mysql = MySQL(app)

def get_all_items():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM car_data")
    items = cur.fetchall()
    cur.close()
    return items

# Add functions for CRUD operations here
