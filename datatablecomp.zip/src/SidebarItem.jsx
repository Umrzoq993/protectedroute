// import "./styles.css";
import React, { useState } from "react";
import {
  RiHome4Line,
  RiTeamLine,
  RiCalendar2Line,
  RiFolder2Line,
  RiUserFollowLine,
  RiPlantLine,
  RiStackLine,
  RiUserUnfollowLine,
} from "react-icons/ri";
import { FiChevronsLeft, FiChevronsRight } from "react-icons/fi/";
import {
  Sidebar,
  SubMenu,
  Menu,
  MenuItem,
  // useProSidebar
} from "react-pro-sidebar";

function Sidebars() {
  const [collapsed, setCollapsed] = useState(false);
  const [toggled, setToggled] = useState(false);

  const handleToggleSidebar = (value) => {
    setToggled(value);
  };

  const handleCollapsedChange = () => {
    setCollapsed(!collapsed);
  };

  const logoMenuItem = collapsed ? (
    <MenuItem icon={<FiChevronsRight />} onClick={handleCollapsedChange} />
  ) : (
    <MenuItem suffix={<FiChevronsLeft />} onClick={handleCollapsedChange}>
      <div
        style={{
          padding: "9px",
          fontWeight: "bold",
          fontSize: 14,
          letterSpacing: "1px",
        }}
      >
        YOUR LOGO!..
      </div>
    </MenuItem>
  );

  return (
    <div>
      <Sidebar
        className={`app ${toggled ? "toggled" : ""}`}
        style={{ height: "100%", position: "absolute" }}
        collapsed={collapsed}
        toggled={toggled}
        handleToggleSidebar={handleToggleSidebar}
        handleCollapsedChange={handleCollapsedChange}
      >
        <main>
          <Menu>
            {logoMenuItem}
            <hr />

            <MenuItem icon={<RiHome4Line />}>Dashboard</MenuItem>

            <SubMenu defaultOpen label={"Professors"} icon={<RiTeamLine />}>
              <SubMenu icon={<RiUserFollowLine />} label={"SubMenu"}>
                <MenuItem>SubMenu 1</MenuItem>
                <MenuItem>SubMenu 2</MenuItem>
                <MenuItem>SubMenu 3</MenuItem>
              </SubMenu>
              <MenuItem icon={<RiUserUnfollowLine />}>Ex Professors</MenuItem>
              <MenuItem icon={<RiCalendar2Line />}>Probation Period</MenuItem>
            </SubMenu>

            <SubMenu defaultOpen label={"Records"} icon={<RiFolder2Line />}>
              <MenuItem icon={<RiStackLine />}>Senior Students</MenuItem>
              <MenuItem icon={<RiPlantLine />}>Junior Students</MenuItem>
            </SubMenu>
          </Menu>
        </main>
      </Sidebar>
    </div>
  );
}

export default Sidebars;
