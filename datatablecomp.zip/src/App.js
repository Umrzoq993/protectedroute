import React from "react";
import Sidebars from "./SidebarItem";

const App = () => {
  return (
    <div>
      <Sidebars />
    </div>
  );
};

export default App;
